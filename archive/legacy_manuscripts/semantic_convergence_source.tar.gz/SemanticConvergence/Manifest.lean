namespace SemanticConvergence

/-- Generated status marker for each manuscript item. -/
inductive FormalizationStatus where
  | declared
  | wrapped
  | derived
deriving Repr, DecidableEq

/-- Generated first-principles status marker for each manuscript item. -/
inductive FirstPrinciplesStatus where
  | abstractInterface
  | concreteStack
deriving Repr, DecidableEq

/-- Generated concrete-migration status marker for each manuscript item. -/
inductive MigrationStatus where
  | pendingConcreteMigration
  | migratedToConcrete
deriving Repr, DecidableEq

/-- Generated proof-shape classification for one manuscript declaration. -/
inductive ProofKind where
  | definition
  | substantive
  | singleLemmaApplication
  | definitionalUnfold
  | fieldProjection
  | constructiveExistential
  | rateComposition
  | placeholderTruth
  | heuristicOther
deriving Repr, DecidableEq

/-- Generated metadata for one core manuscript declaration. -/
structure ManifestEntry where
  texLabel : String
  kind : String
  title : String
  startLine : Nat
  endLine : Nat
  leanModule : String
  declName : String
  qualifiedDeclName : String
  status : FormalizationStatus
  firstPrinciplesStatus : FirstPrinciplesStatus
  migrationStatus : MigrationStatus
  proofKind : ProofKind
  exactnessLockPending : Bool
  exactnessLockNote : String
  publicProbabilisticBridgeSurface : Bool
  publicProbabilisticBridgeWitnessHyp : Bool
  publicProbabilisticBridgeEquationHyp : Bool
  publicProbabilisticBridgeConcreteRoot : Bool
deriving Repr, DecidableEq

/-- Generated coverage list for the canonical TeX source. -/
def manifestEntries : List ManifestEntry :=
  [
    { texLabel := "def:history-compat"
      kind := "definition"
      title := "History-compatible set"
      startLine := 184
      endLine := 192
      leanModule := "SemanticConvergence.Hierarchy"
      declName := "def_history_compat"
      qualifiedDeclName := "SemanticConvergence.def_history_compat"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:policy-pred"
      kind := "definition"
      title := "Policy-predictable set"
      startLine := 194
      endLine := 202
      leanModule := "SemanticConvergence.Hierarchy"
      declName := "def_policy_pred"
      qualifiedDeclName := "SemanticConvergence.def_policy_pred"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:int-sem-class"
      kind := "definition"
      title := "Interventional semantic class"
      startLine := 204
      endLine := 216
      leanModule := "SemanticConvergence.Hierarchy"
      declName := "def_int_sem_class"
      qualifiedDeclName := "SemanticConvergence.def_int_sem_class"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:observer"
      kind := "definition"
      title := "Observer"
      startLine := 220
      endLine := 223
      leanModule := "SemanticConvergence.Foundations"
      declName := "def_observer"
      qualifiedDeclName := "SemanticConvergence.def_observer"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "lem:nesting"
      kind := "lemma"
      title := "Nesting"
      startLine := 232
      endLine := 238
      leanModule := "SemanticConvergence.Hierarchy"
      declName := "lem_nesting"
      qualifiedDeclName := "SemanticConvergence.lem_nesting"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:refinement-chain"
      kind := "proposition"
      title := "Refinement chain"
      startLine := 248
      endLine := 254
      leanModule := "SemanticConvergence.Hierarchy"
      declName := "prop_refinement_chain"
      qualifiedDeclName := "SemanticConvergence.prop_refinement_chain"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "lem:observable-quotient"
      kind := "lemma"
      title := "Interventional semantic classes are the observable quotient"
      startLine := 262
      endLine := 265
      leanModule := "SemanticConvergence.Hierarchy"
      declName := "lem_observable_quotient"
      qualifiedDeclName := "SemanticConvergence.lem_observable_quotient"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:history-recoverable"
      kind := "definition"
      title := "History-recoverable target"
      startLine := 277
      endLine := 285
      leanModule := "SemanticConvergence.Hierarchy"
      declName := "def_history_recoverable"
      qualifiedDeclName := "SemanticConvergence.def_history_recoverable"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "thm:factor-through-quotient"
      kind := "theorem"
      title := "Every history-recoverable target factors through the semantic quotient"
      startLine := 287
      endLine := 290
      leanModule := "SemanticConvergence.Hierarchy"
      declName := "thm_factor_through_quotient"
      qualifiedDeclName := "SemanticConvergence.thm_factor_through_quotient"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "lem:fit-gap"
      kind := "lemma"
      title := "{Fit gap: $R_\\pi(p^\\star)\\subsetneq R_{h_t}(p^\\star)$}"
      startLine := 302
      endLine := 305
      leanModule := "SemanticConvergence.Hierarchy"
      declName := "lem_fit_gap"
      qualifiedDeclName := "SemanticConvergence.lem_fit_gap"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "thm:policy-gap"
      kind := "theorem"
      title := "{Policy gap: $[p^\\star"
      startLine := 311
      endLine := 314
      leanModule := "SemanticConvergence.Hierarchy"
      declName := "thm_policy_gap"
      qualifiedDeclName := "SemanticConvergence.thm_policy_gap"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "lem:syntactic-gap"
      kind := "lemma"
      title := "{Syntactic gap: $\\{p^\\star\\}\\subsetneq [p^\\star"
      startLine := 338
      endLine := 341
      leanModule := "SemanticConvergence.Hierarchy"
      declName := "lem_syntactic_gap"
      qualifiedDeclName := "SemanticConvergence.lem_syntactic_gap"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "thm:strict-hierarchy"
      kind := "theorem"
      title := "Strict knowability hierarchy"
      startLine := 351
      endLine := 357
      leanModule := "SemanticConvergence.Hierarchy"
      declName := "thm_strict_hierarchy"
      qualifiedDeclName := "SemanticConvergence.thm_strict_hierarchy"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:bhat-omega"
      kind := "definition"
      title := "Bhattacharyya separation at observer $\\omega$"
      startLine := 416
      endLine := 423
      leanModule := "SemanticConvergence.Functional"
      declName := "def_bhat_omega"
      qualifiedDeclName := "SemanticConvergence.def_bhat_omega"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:raw-two-observer-functional"
      kind := "definition"
      title := "Raw policy-coupled scaffold"
      startLine := 432
      endLine := 447
      leanModule := "SemanticConvergence.Functional"
      declName := "def_raw_two_observer_functional"
      qualifiedDeclName := "SemanticConvergence.def_raw_two_observer_functional"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:two-observer-functional"
      kind := "definition"
      title := "Two-observer variational functional"
      startLine := 456
      endLine := 474
      leanModule := "SemanticConvergence.Functional"
      declName := "def_two_observer_functional"
      qualifiedDeclName := "SemanticConvergence.def_two_observer_functional"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:two-observer-minimizer"
      kind := "proposition"
      title := "Exact global minimizer of the two-observer functional"
      startLine := 476
      endLine := 486
      leanModule := "SemanticConvergence.Functional"
      declName := "prop_two_observer_minimizer"
      qualifiedDeclName := "SemanticConvergence.prop_two_observer_minimizer"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:kernel-functional"
      kind := "definition"
      title := "Kernel lift of the two-observer functional"
      startLine := 511
      endLine := 521
      leanModule := "SemanticConvergence.Functional"
      declName := "def_kernel_functional"
      qualifiedDeclName := "SemanticConvergence.def_kernel_functional"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:kernel-functional-minimizer"
      kind := "proposition"
      title := "Exact global minimizer of the kernel lift"
      startLine := 523
      endLine := 533
      leanModule := "SemanticConvergence.Functional"
      declName := "prop_kernel_functional_minimizer"
      qualifiedDeclName := "SemanticConvergence.prop_kernel_functional_minimizer"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:kernel-functional-minimizer-compact"
      kind := "proposition"
      title := "Exact global minimizer of the compact-action kernel lift"
      startLine := 560
      endLine := 581
      leanModule := "SemanticConvergence.Functional"
      declName := "prop_kernel_functional_minimizer_compact"
      qualifiedDeclName := "SemanticConvergence.prop_kernel_functional_minimizer_compact"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := true
      exactnessLockNote := "Current Lean declaration is an exact finite-action specialization; the measure-theoretic compact/Borel kernel theorem is locked in compact_kernel_exactness_lock.md."
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:meeting-point-shorthand"
      kind := "definition"
      title := "Meeting-point specialization"
      startLine := 609
      endLine := 620
      leanModule := "SemanticConvergence.Functional"
      declName := "def_meeting_point_shorthand"
      qualifiedDeclName := "SemanticConvergence.def_meeting_point_shorthand"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:belief-invariance-above"
      kind := "proposition"
      title := "Belief-observer invariance above $\\omega_{\\mathrm{behav}}$"
      startLine := 629
      endLine := 636
      leanModule := "SemanticConvergence.Functional"
      declName := "prop_belief_invariance_above"
      qualifiedDeclName := "SemanticConvergence.prop_belief_invariance_above"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:belief-illtyped-below"
      kind := "proposition"
      title := "Belief-observer ill-typing below $\\omega_{\\mathrm{behav}}$"
      startLine := 649
      endLine := 652
      leanModule := "SemanticConvergence.Functional"
      declName := "prop_belief_illtyped_below"
      qualifiedDeclName := "SemanticConvergence.prop_belief_illtyped_below"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:action-cap"
      kind := "proposition"
      title := "Action-observer cap"
      startLine := 665
      endLine := 673
      leanModule := "SemanticConvergence.Functional"
      declName := "prop_action_cap"
      qualifiedDeclName := "SemanticConvergence.prop_action_cap"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "cor:twins-frozen-ratio"
      kind := "corollary"
      title := "Behavioral twins have frozen posterior ratio"
      startLine := 687
      endLine := 694
      leanModule := "SemanticConvergence.Functional"
      declName := "cor_twins_frozen_ratio"
      qualifiedDeclName := "SemanticConvergence.cor_twins_frozen_ratio"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "thm:meeting-point"
      kind := "theorem"
      title := "Meeting point"
      startLine := 709
      endLine := 719
      leanModule := "SemanticConvergence.Functional"
      declName := "thm_meeting_point"
      qualifiedDeclName := "SemanticConvergence.thm_meeting_point"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "cor:canonical-pair"
      kind := "corollary"
      title := "Canonical two-observer choice"
      startLine := 725
      endLine := 728
      leanModule := "SemanticConvergence.Functional"
      declName := "cor_canonical_pair"
      qualifiedDeclName := "SemanticConvergence.cor_canonical_pair"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:goal-dialed"
      kind := "proposition"
      title := "Goal-dialed convergence"
      startLine := 742
      endLine := 752
      leanModule := "SemanticConvergence.Belief"
      declName := "prop_goal_dialed"
      qualifiedDeclName := "SemanticConvergence.prop_goal_dialed"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:universal-prior"
      kind := "definition"
      title := "Universal interactive prior"
      startLine := 784
      endLine := 796
      leanModule := "SemanticConvergence.Belief"
      declName := "def_universal_prior"
      qualifiedDeclName := "SemanticConvergence.def_universal_prior"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "lem:prior-invariance"
      kind := "lemma"
      title := "Machine invariance"
      startLine := 798
      endLine := 807
      leanModule := "SemanticConvergence.Belief"
      declName := "lem_prior_invariance"
      qualifiedDeclName := "SemanticConvergence.lem_prior_invariance"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "lem:prior-necessity"
      kind := "lemma"
      title := "{Positive prior mass on $[p^\\star"
      startLine := 821
      endLine := 824
      leanModule := "SemanticConvergence.Belief"
      declName := "lem_prior_necessity"
      qualifiedDeclName := "SemanticConvergence.lem_prior_necessity"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:afe"
      kind := "definition"
      title := "Algorithmic free energy"
      startLine := 838
      endLine := 845
      leanModule := "SemanticConvergence.Belief"
      declName := "def_afe"
      qualifiedDeclName := "SemanticConvergence.def_afe"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "lem:variational"
      kind := "lemma"
      title := "Variational identity"
      startLine := 847
      endLine := 860
      leanModule := "SemanticConvergence.Belief"
      declName := "lem_variational"
      qualifiedDeclName := "SemanticConvergence.lem_variational"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "lem:kl-necessity"
      kind := "lemma"
      title := "KL is forced by the exact Gibbs variational formula"
      startLine := 878
      endLine := 892
      leanModule := "SemanticConvergence.Belief"
      declName := "lem_kl_necessity"
      qualifiedDeclName := "SemanticConvergence.lem_kl_necessity"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "lem:merging"
      kind := "lemma"
      title := "Predictive merging"
      startLine := 910
      endLine := 925
      leanModule := "SemanticConvergence.Belief"
      declName := "lem_merging"
      qualifiedDeclName := "SemanticConvergence.lem_merging"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:class-complement"
      kind := "definition"
      title := "Class-complement predictive law"
      startLine := 949
      endLine := 958
      leanModule := "SemanticConvergence.Semantic"
      declName := "def_class_complement"
      qualifiedDeclName := "SemanticConvergence.def_class_complement"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:semantic-gain"
      kind := "definition"
      title := "Semantic gain"
      startLine := 965
      endLine := 976
      leanModule := "SemanticConvergence.Semantic"
      declName := "def_semantic_gain"
      qualifiedDeclName := "SemanticConvergence.def_semantic_gain"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "lem:odds-identity"
      kind := "lemma"
      title := "Posterior-odds identity"
      startLine := 978
      endLine := 989
      leanModule := "SemanticConvergence.Semantic"
      declName := "lem_odds_identity"
      qualifiedDeclName := "SemanticConvergence.lem_odds_identity"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:semantic-separation"
      kind := "definition"
      title := "Semantic separation"
      startLine := 1001
      endLine := 1012
      leanModule := "SemanticConvergence.Semantic"
      declName := "def_semantic_separation"
      qualifiedDeclName := "SemanticConvergence.def_semantic_separation"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "lem:zero-criterion"
      kind := "lemma"
      title := "Zero criterion"
      startLine := 1019
      endLine := 1029
      leanModule := "SemanticConvergence.Semantic"
      declName := "lem_zero_criterion"
      qualifiedDeclName := "SemanticConvergence.lem_zero_criterion"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:chernoff-correspondence"
      kind := "proposition"
      title := "Chernoff--Bhattacharyya correspondence"
      startLine := 1035
      endLine := 1046
      leanModule := "SemanticConvergence.Semantic"
      declName := "prop_chernoff_correspondence"
      qualifiedDeclName := "SemanticConvergence.prop_chernoff_correspondence"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:semantic-rule"
      kind := "definition"
      title := "Semantic action rule"
      startLine := 1064
      endLine := 1086
      leanModule := "SemanticConvergence.Semantic"
      declName := "def_semantic_rule"
      qualifiedDeclName := "SemanticConvergence.def_semantic_rule"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:promotion-supporting"
      kind := "definition"
      title := "Promotion-supporting action rule"
      startLine := 1090
      endLine := 1097
      leanModule := "SemanticConvergence.Semantic"
      declName := "def_promotion_supporting"
      qualifiedDeclName := "SemanticConvergence.def_promotion_supporting"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:semantic-is-promotion-supporting"
      kind := "proposition"
      title := "Semantic rule is promotion-supporting"
      startLine := 1099
      endLine := 1110
      leanModule := "SemanticConvergence.Semantic"
      declName := "prop_semantic_is_promotion_supporting"
      qualifiedDeclName := "SemanticConvergence.prop_semantic_is_promotion_supporting"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:kernel-semantic-rule"
      kind := "definition"
      title := "Kernel semantic action rule"
      startLine := 1128
      endLine := 1135
      leanModule := "SemanticConvergence.Semantic"
      declName := "def_kernel_semantic_rule"
      qualifiedDeclName := "SemanticConvergence.def_kernel_semantic_rule"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:kernel-promotion-support"
      kind := "proposition"
      title := "Kernel rule has reference-mass promotion support"
      startLine := 1137
      endLine := 1146
      leanModule := "SemanticConvergence.Semantic"
      declName := "prop_kernel_promotion_support"
      qualifiedDeclName := "SemanticConvergence.prop_kernel_promotion_support"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:kernel-promotion-support-compact"
      kind := "proposition"
      title := "Compact-action kernel rule has reference-mass promotion support"
      startLine := 1169
      endLine := 1181
      leanModule := "SemanticConvergence.Semantic"
      declName := "prop_kernel_promotion_support_compact"
      qualifiedDeclName := "SemanticConvergence.prop_kernel_promotion_support_compact"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := true
      exactnessLockNote := "Downstream compact-action support theorem must be rechecked after the measure-theoretic compact kernel theorem lands."
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:decodable-channel"
      kind := "definition"
      title := "Decodable observation channel"
      startLine := 1207
      endLine := 1222
      leanModule := "SemanticConvergence.Noise"
      declName := "def_decodable_channel"
      qualifiedDeclName := "SemanticConvergence.def_decodable_channel"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:noise-immunity"
      kind := "proposition"
      title := "Pointwise noise-channel monotonicity"
      startLine := 1224
      endLine := 1232
      leanModule := "SemanticConvergence.Noise"
      declName := "prop_noise_immunity"
      qualifiedDeclName := "SemanticConvergence.prop_noise_immunity"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:left-invertible-channel"
      kind := "definition"
      title := "Left-invertible finite observation channel"
      startLine := 1248
      endLine := 1257
      leanModule := "SemanticConvergence.Noise"
      declName := "def_left_invertible_channel"
      qualifiedDeclName := "SemanticConvergence.def_left_invertible_channel"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:noise-left-invertible"
      kind := "proposition"
      title := "Uniform positive separation under left-invertible finite noise"
      startLine := 1259
      endLine := 1287
      leanModule := "SemanticConvergence.Noise"
      declName := "prop_noise_left_invertible"
      qualifiedDeclName := "SemanticConvergence.prop_noise_left_invertible"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.constructiveExistential
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:noise-decoding"
      kind := "proposition"
      title := "Exact preservation under decodable recodings"
      startLine := 1333
      endLine := 1354
      leanModule := "SemanticConvergence.Noise"
      declName := "prop_noise_decoding"
      qualifiedDeclName := "SemanticConvergence.prop_noise_decoding"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "cor:noise-transfer"
      kind := "corollary"
      title := "Exact transfer under decodable observation recodings"
      startLine := 1424
      endLine := 1446
      leanModule := "SemanticConvergence.Noise"
      declName := "cor_noise_transfer"
      qualifiedDeclName := "SemanticConvergence.cor_noise_transfer"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := true
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := true },
    { texLabel := "cor:noise-left-invertible-history-independent"
      kind := "corollary"
      title := "Left-invertible noisy transfer in the history-independent setting"
      startLine := 1519
      endLine := 1548
      leanModule := "SemanticConvergence.Semantic"
      declName := "cor_noise_left_invertible_history_independent"
      qualifiedDeclName := "SemanticConvergence.cor_noise_left_invertible_history_independent"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:sep-condition"
      kind := "definition"
      title := "Semantic separation condition"
      startLine := 1692
      endLine := 1698
      leanModule := "SemanticConvergence.Semantic"
      declName := "def_sep_condition"
      qualifiedDeclName := "SemanticConvergence.def_sep_condition"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:uniform-history-independent-separation"
      kind := "definition"
      title := "Uniform history-independent semantic separation"
      startLine := 1700
      endLine := 1722
      leanModule := "SemanticConvergence.Semantic"
      declName := "def_uniform_history_independent_separation"
      qualifiedDeclName := "SemanticConvergence.def_uniform_history_independent_separation"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:uniform-history-independent-implies-semantic"
      kind := "proposition"
      title := "Uniform history-independent separation implies semantic separation"
      startLine := 1724
      endLine := 1727
      leanModule := "SemanticConvergence.Semantic"
      declName := "prop_uniform_history_independent_implies_semantic"
      qualifiedDeclName := "SemanticConvergence.prop_uniform_history_independent_implies_semantic"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "cor:kl-implies-semantic-separation"
      kind := "corollary"
      title := "Uniform KL class-vs.-complement separation implies semantic separation"
      startLine := 1754
      endLine := 1766
      leanModule := "SemanticConvergence.Semantic"
      declName := "cor_kl_implies_semantic_separation"
      qualifiedDeclName := "SemanticConvergence.cor_kl_implies_semantic_separation"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "cor:event-witness-implies-semantic-separation"
      kind := "corollary"
      title := "Event-witness separation implies semantic separation"
      startLine := 1780
      endLine := 1796
      leanModule := "SemanticConvergence.Semantic"
      declName := "cor_event_witness_implies_semantic_separation"
      qualifiedDeclName := "SemanticConvergence.cor_event_witness_implies_semantic_separation"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:kernel-sep-condition"
      kind := "definition"
      title := "Kernel semantic separation condition relative to $\\lambda$"
      startLine := 1834
      endLine := 1840
      leanModule := "SemanticConvergence.Semantic"
      declName := "def_kernel_sep_condition"
      qualifiedDeclName := "SemanticConvergence.def_kernel_sep_condition"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:finite-action-kernel-separation"
      kind := "proposition"
      title := "Finite-action lift of semantic separation"
      startLine := 1842
      endLine := 1852
      leanModule := "SemanticConvergence.Semantic"
      declName := "prop_finite_action_kernel_separation"
      qualifiedDeclName := "SemanticConvergence.prop_finite_action_kernel_separation"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:compact-action-kernel-separation"
      kind := "proposition"
      title := "Compact-action lift of semantic separation"
      startLine := 1862
      endLine := 1884
      leanModule := "SemanticConvergence.Semantic"
      declName := "prop_compact_action_kernel_separation"
      qualifiedDeclName := "SemanticConvergence.prop_compact_action_kernel_separation"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := true
      exactnessLockNote := "Downstream compact-action separation theorem must be rechecked against compact reference-measure and full-support hypotheses."
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "lem:conditional-bc"
      kind := "lemma"
      title := "Conditional Borel--Cantelli"
      startLine := 1928
      endLine := 1931
      leanModule := "SemanticConvergence.Semantic"
      declName := "lem_conditional_bc"
      qualifiedDeclName := "SemanticConvergence.lem_conditional_bc"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "lem:contraction"
      kind := "lemma"
      title := "Cumulative separation drives posterior odds to zero"
      startLine := 1937
      endLine := 1946
      leanModule := "SemanticConvergence.Semantic"
      declName := "lem_contraction"
      qualifiedDeclName := "SemanticConvergence.lem_contraction"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.constructiveExistential
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:full-support-behavioral"
      kind := "proposition"
      title := "Full-support policies recover the behavioral observer"
      startLine := 1970
      endLine := 1982
      leanModule := "SemanticConvergence.Semantic"
      declName := "prop_full_support_behavioral"
      qualifiedDeclName := "SemanticConvergence.prop_full_support_behavioral"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    /-
    `thm:separating-support-convergence` names the countable probabilistic
    Section 6 theorem on `CountablePrefixMachine` and realized trajectory laws.
    Its current proof path is first-principles: the probabilistic theorem
    is derived from the deterministic `ConcretePrefixMachine` soft-substrate
    contraction through the explicit bridge layer in
    `ConcreteSubstrateBridge`, and the selector/kernel realizations are
    then rethreaded through that bridged theorem stack.
    -/
    { texLabel := "thm:separating-support-convergence"
      kind := "theorem"
      title := "Sufficient conditions for semantic recovery"
      startLine := 2023
      endLine := 2052
      leanModule := "SemanticConvergence.Semantic"
      declName := "thm_separating_support_convergence"
      qualifiedDeclName := "SemanticConvergence.thm_separating_support_convergence"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := true
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := true },
    { texLabel := "thm:exploration-floor-behavioral"
      kind := "theorem"
      title := "Full-support exploration floors recover the behavioral target"
      startLine := 2084
      endLine := 2106
      leanModule := "SemanticConvergence.Semantic"
      declName := "thm_exploration_floor_behavioral"
      qualifiedDeclName := "SemanticConvergence.thm_exploration_floor_behavioral"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.constructiveExistential
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "thm:separating-support-rate"
      kind := "theorem"
      title := "Rates from cumulative separating-action support"
      startLine := 2135
      endLine := 2190
      leanModule := "SemanticConvergence.Semantic"
      declName := "thm_separating_support_rate"
      qualifiedDeclName := "SemanticConvergence.thm_separating_support_rate"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := true
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := true },
    { texLabel := "cor:separating-support-finite-time"
      kind := "corollary"
      title := "Explicit finite-time recovery guarantee"
      startLine := 2281
      endLine := 2293
      leanModule := "SemanticConvergence.Semantic"
      declName := "cor_separating_support_finite_time"
      qualifiedDeclName := "SemanticConvergence.cor_separating_support_finite_time"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := true
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := true },
    { texLabel := "thm:semantic-convergence"
      kind := "theorem"
      title := "Canonical selector realization of semantic convergence"
      startLine := 2332
      endLine := 2347
      leanModule := "SemanticConvergence.Semantic"
      declName := "thm_semantic_convergence"
      qualifiedDeclName := "SemanticConvergence.thm_semantic_convergence"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "thm:kernel-semantic-convergence"
      kind := "theorem"
      title := "Kernel-functional semantic convergence"
      startLine := 2392
      endLine := 2407
      leanModule := "SemanticConvergence.Semantic"
      declName := "thm_kernel_semantic_convergence"
      qualifiedDeclName := "SemanticConvergence.thm_kernel_semantic_convergence"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "cor:compact-action-kernel"
      kind := "corollary"
      title := "Compact-action extension of the kernel theorem and rates"
      startLine := 2430
      endLine := 2464
      leanModule := "SemanticConvergence.Semantic"
      declName := "cor_compact_action_kernel"
      qualifiedDeclName := "SemanticConvergence.cor_compact_action_kernel"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := true
      exactnessLockNote := "Downstream compact-action kernel corollary must be rethreaded through the measure-theoretic compact kernel theorem."
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "cor:finite-maximin"
      kind := "corollary"
      title := "Finite-class deterministic specialization"
      startLine := 2498
      endLine := 2509
      leanModule := "SemanticConvergence.Semantic"
      declName := "cor_finite_maximin"
      qualifiedDeclName := "SemanticConvergence.cor_finite_maximin"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "cor:support-necessary"
      kind := "theorem"
      title := "Zero separating support makes semantic recovery impossible"
      startLine := 2530
      endLine := 2538
      leanModule := "SemanticConvergence.Semantic"
      declName := "cor_support_necessary"
      qualifiedDeclName := "SemanticConvergence.cor_support_necessary"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.constructiveExistential
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "thm:summable-support-insufficient"
      kind := "theorem"
      title := "Summable separating support is insufficient"
      startLine := 2555
      endLine := 2581
      leanModule := "SemanticConvergence.Semantic"
      declName := "thm_summable_support_insufficient"
      qualifiedDeclName := "SemanticConvergence.thm_summable_support_insufficient"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.constructiveExistential
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "lem:one-step-drift"
      kind := "lemma"
      title := "Canonical selector one-step drift"
      startLine := 2653
      endLine := 2665
      leanModule := "SemanticConvergence.Rates"
      declName := "lem_one_step_drift"
      qualifiedDeclName := "SemanticConvergence.lem_one_step_drift"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := true
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := true },
    { texLabel := "prop:exp-rate"
      kind := "proposition"
      title := "Positive-floor exponential rate, expectation form"
      startLine := 2692
      endLine := 2711
      leanModule := "SemanticConvergence.Rates"
      declName := "prop_exp_rate"
      qualifiedDeclName := "SemanticConvergence.prop_exp_rate"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.rateComposition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := true
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := true },
    { texLabel := "lem:one-step-drift-kernel"
      kind := "lemma"
      title := "Kernel one-step drift"
      startLine := 2723
      endLine := 2735
      leanModule := "SemanticConvergence.Rates"
      declName := "lem_one_step_drift_kernel"
      qualifiedDeclName := "SemanticConvergence.lem_one_step_drift_kernel"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:kernel-exp-rate"
      kind := "proposition"
      title := "Same-view transfer of the positive-floor exponential rate"
      startLine := 2766
      endLine := 2786
      leanModule := "SemanticConvergence.Rates"
      declName := "prop_kernel_exp_rate"
      qualifiedDeclName := "SemanticConvergence.prop_kernel_exp_rate"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.rateComposition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := true
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := true },
    { texLabel := "thm:exp-rate-concentration"
      kind := "theorem"
      title := "Finite-time positive-floor rate transfer"
      startLine := 2798
      endLine := 2832
      leanModule := "SemanticConvergence.Semantic"
      declName := "thm_exp_rate_concentration"
      qualifiedDeclName := "SemanticConvergence.thm_exp_rate_concentration"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.rateComposition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := true
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := true },
    { texLabel := "cor:goal-dialed-payoff"
      kind := "corollary"
      title := "Goal-dialed convergence"
      startLine := 2900
      endLine := 2908
      leanModule := "SemanticConvergence.Semantic"
      declName := "cor_goal_dialed_payoff"
      qualifiedDeclName := "SemanticConvergence.cor_goal_dialed_payoff"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:finite-time-policy-observer"
      kind := "definition"
      title := "Finite-time policy observer"
      startLine := 2926
      endLine := 2933
      leanModule := "SemanticConvergence.SelfReference"
      declName := "def_finite_time_policy_observer"
      qualifiedDeclName := "SemanticConvergence.def_finite_time_policy_observer"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "lem:monotone-refinement"
      kind := "lemma"
      title := "Monotone refinement toward $\\omega_\\pi$"
      startLine := 2935
      endLine := 2945
      leanModule := "SemanticConvergence.SelfReference"
      declName := "lem_monotone_refinement"
      qualifiedDeclName := "SemanticConvergence.lem_monotone_refinement"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:self-ref-rule"
      kind := "definition"
      title := "Self-referential semantic rule"
      startLine := 2956
      endLine := 2959
      leanModule := "SemanticConvergence.SelfReference"
      declName := "def_self_ref_rule"
      qualifiedDeclName := "SemanticConvergence.def_self_ref_rule"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "lem:exploration-reachability"
      kind := "lemma"
      title := "Promotion-floor reachability"
      startLine := 2973
      endLine := 2988
      leanModule := "SemanticConvergence.SelfReference"
      declName := "lem_exploration_reachability"
      qualifiedDeclName := "SemanticConvergence.lem_exploration_reachability"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.constructiveExistential
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:observer-promotion-sr"
      kind := "proposition"
      title := "Eventual isolation criterion"
      startLine := 2994
      endLine := 3018
      leanModule := "SemanticConvergence.SelfReference"
      declName := "prop_observer_promotion_sr"
      qualifiedDeclName := "SemanticConvergence.prop_observer_promotion_sr"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "thm:self-ref-convergence"
      kind := "theorem"
      title := "Self-referential convergence under eventual isolation"
      startLine := 3031
      endLine := 3044
      leanModule := "SemanticConvergence.SelfReference"
      declName := "thm_self_ref_convergence"
      qualifiedDeclName := "SemanticConvergence.thm_self_ref_convergence"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:self-ref-obstruction"
      kind := "proposition"
      title := "Unconditional eventual isolation fails"
      startLine := 3077
      endLine := 3093
      leanModule := "SemanticConvergence.SelfReference"
      declName := "prop_self_ref_obstruction"
      qualifiedDeclName := "SemanticConvergence.prop_self_ref_obstruction"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:self-ref-exploratory"
      kind := "definition"
      title := "Exploration-completed self-referential rule"
      startLine := 3177
      endLine := 3192
      leanModule := "SemanticConvergence.SelfReference"
      declName := "def_self_ref_exploratory"
      qualifiedDeclName := "SemanticConvergence.def_self_ref_exploratory"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "thm:self-ref-exploratory"
      kind := "theorem"
      title := "Exploration-completed self-reference with divergent exploration budget"
      startLine := 3194
      endLine := 3207
      leanModule := "SemanticConvergence.SelfReference"
      declName := "thm_self_ref_exploratory"
      qualifiedDeclName := "SemanticConvergence.thm_self_ref_exploratory"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "thm:self-ref-exploratory-rate"
      kind := "theorem"
      title := "Rates for exploration-completed self-reference"
      startLine := 3219
      endLine := 3258
      leanModule := "SemanticConvergence.SelfReference"
      declName := "thm_self_ref_exploratory_rate"
      qualifiedDeclName := "SemanticConvergence.thm_self_ref_exploratory_rate"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:self-ref-one-step-split"
      kind := "proposition"
      title := "One-step splitting criterion"
      startLine := 3287
      endLine := 3311
      leanModule := "SemanticConvergence.SelfReference"
      declName := "prop_self_ref_one_step_split"
      qualifiedDeclName := "SemanticConvergence.prop_self_ref_one_step_split"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.constructiveExistential
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "thm:self-ref-sharp"
      kind := "theorem"
      title := "Sharpened self-referential convergence under deterministic splitting"
      startLine := 3348
      endLine := 3378
      leanModule := "SemanticConvergence.SelfReference"
      declName := "thm_self_ref_sharp"
      qualifiedDeclName := "SemanticConvergence.thm_self_ref_sharp"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:boundary-identity"
      kind := "proposition"
      title := "Boundary identification under Bayes/Gibbs belief"
      startLine := 3420
      endLine := 3424
      leanModule := "SemanticConvergence.Boundary"
      declName := "prop_boundary_identity"
      qualifiedDeclName := "SemanticConvergence.prop_boundary_identity"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:efe"
      kind := "definition"
      title := "Expected free energy"
      startLine := 3443
      endLine := 3457
      leanModule := "SemanticConvergence.Boundary"
      declName := "def_efe"
      qualifiedDeclName := "SemanticConvergence.def_efe"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "lem:risk-ig"
      kind := "lemma"
      title := "Risk minus information gain"
      startLine := 3459
      endLine := 3469
      leanModule := "SemanticConvergence.Boundary"
      declName := "lem_risk_ig"
      qualifiedDeclName := "SemanticConvergence.lem_risk_ig"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "cor:efe-specialization"
      kind := "corollary"
      title := "Expected free energy as a unifying epistemic principle"
      startLine := 3475
      endLine := 3478
      leanModule := "SemanticConvergence.Boundary"
      declName := "cor_efe_specialization"
      qualifiedDeclName := "SemanticConvergence.cor_efe_specialization"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "def:afe-principle"
      kind := "definition"
      title := "Algorithmic free energy principle"
      startLine := 3491
      endLine := 3499
      leanModule := "SemanticConvergence.Boundary"
      declName := "def_afe_principle"
      qualifiedDeclName := "SemanticConvergence.def_afe_principle"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "lem:info-decomp"
      kind := "lemma"
      title := "Information decomposition"
      startLine := 3508
      endLine := 3516
      leanModule := "SemanticConvergence.Boundary"
      declName := "lem_info_decomp"
      qualifiedDeclName := "SemanticConvergence.lem_info_decomp"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.definition
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "thm:afe-near-miss"
      kind := "theorem"
      title := "Near-miss: the algorithmic free energy principle does not imply semantic convergence"
      startLine := 3534
      endLine := 3542
      leanModule := "SemanticConvergence.Boundary"
      declName := "thm_afe_near_miss"
      qualifiedDeclName := "SemanticConvergence.thm_afe_near_miss"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.constructiveExistential
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "thm:observer-promotion-failure"
      kind := "theorem"
      title := "Observer-promotion failure of the AFE principle"
      startLine := 3634
      endLine := 3641
      leanModule := "SemanticConvergence.Boundary"
      declName := "thm_observer_promotion_failure"
      qualifiedDeclName := "SemanticConvergence.thm_observer_promotion_failure"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "cor:observer-promotion-universal"
      kind := "corollary"
      title := "Universal-prior case"
      startLine := 3655
      endLine := 3658
      leanModule := "SemanticConvergence.Boundary"
      declName := "cor_observer_promotion_universal"
      qualifiedDeclName := "SemanticConvergence.cor_observer_promotion_universal"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "cor:promotion-contrast"
      kind := "corollary"
      title := "Observer-promotion contrast"
      startLine := 3679
      endLine := 3682
      leanModule := "SemanticConvergence.Semantic"
      declName := "cor_promotion_contrast"
      qualifiedDeclName := "SemanticConvergence.cor_promotion_contrast"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "prop:amortized-surrogate-minimizer"
      kind := "proposition"
      title := "Exact action-side minimizer of the amortized surrogate"
      startLine := 3753
      endLine := 3766
      leanModule := "SemanticConvergence.Surrogate"
      declName := "prop_amortized_surrogate_minimizer"
      qualifiedDeclName := "SemanticConvergence.prop_amortized_surrogate_minimizer"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "thm:amortized-surrogate"
      kind := "theorem"
      title := "Semantic-recovery guarantee for the amortized surrogate"
      startLine := 3772
      endLine := 3827
      leanModule := "SemanticConvergence.Surrogate"
      declName := "thm_amortized_surrogate"
      qualifiedDeclName := "SemanticConvergence.thm_amortized_surrogate"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
    { texLabel := "cor:amortized-surrogate-finite-time"
      kind := "corollary"
      title := "Finite-time guarantee for the amortized surrogate"
      startLine := 3888
      endLine := 3915
      leanModule := "SemanticConvergence.Surrogate"
      declName := "cor_amortized_surrogate_finite_time"
      qualifiedDeclName := "SemanticConvergence.cor_amortized_surrogate_finite_time"
      status := FormalizationStatus.derived
      firstPrinciplesStatus := FirstPrinciplesStatus.concreteStack
      migrationStatus := MigrationStatus.migratedToConcrete
      proofKind := ProofKind.substantive
      exactnessLockPending := false
      exactnessLockNote := ""
      publicProbabilisticBridgeSurface := false
      publicProbabilisticBridgeWitnessHyp := false
      publicProbabilisticBridgeEquationHyp := false
      publicProbabilisticBridgeConcreteRoot := false },
  ]

def manifestEntryCount : Nat := manifestEntries.length

theorem manifestEntryCount_eq : manifestEntryCount = 106 := rfl

def derivedEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.status = FormalizationStatus.derived)

def wrappedEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.status = FormalizationStatus.wrapped)

def declaredEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.status = FormalizationStatus.declared)

def concreteStackEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.firstPrinciplesStatus = FirstPrinciplesStatus.concreteStack)

def abstractInterfaceEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.firstPrinciplesStatus = FirstPrinciplesStatus.abstractInterface)

def migratedToConcreteEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.migrationStatus = MigrationStatus.migratedToConcrete)

def pendingConcreteMigrationEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.migrationStatus = MigrationStatus.pendingConcreteMigration)

def substantiveEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.proofKind = ProofKind.substantive)

def definitionProofEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.proofKind = ProofKind.definition)

def constructiveExistentialEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.proofKind = ProofKind.constructiveExistential)

def rateCompositionEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.proofKind = ProofKind.rateComposition)

def singleLemmaApplicationEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.proofKind = ProofKind.singleLemmaApplication)

def definitionalUnfoldEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.proofKind = ProofKind.definitionalUnfold)

def fieldProjectionEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.proofKind = ProofKind.fieldProjection)

def placeholderTruthEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.proofKind = ProofKind.placeholderTruth)

def heuristicOtherEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.proofKind = ProofKind.heuristicOther)

def manifestDefinitionEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.kind = "definition")

def manifestDefinitionEntriesTaggedAsDefinitionCount : Nat :=
  manifestEntries.countP (fun entry =>
    entry.kind = "definition" && entry.proofKind = ProofKind.definition)

def manifestTheoremLikeEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.kind ≠ "definition")

def manifestTheoremLikeSemanticallyAuditedEntryCount : Nat :=
  manifestEntries.countP (fun entry =>
    entry.kind ≠ "definition" &&
      (entry.proofKind = ProofKind.definition ||
        entry.proofKind = ProofKind.substantive ||
        entry.proofKind = ProofKind.constructiveExistential ||
        entry.proofKind = ProofKind.rateComposition))

def suspiciousManifestEntryCount : Nat :=
  manifestEntries.countP (fun entry =>
    entry.proofKind = ProofKind.singleLemmaApplication ||
      entry.proofKind = ProofKind.definitionalUnfold ||
      entry.proofKind = ProofKind.fieldProjection ||
      entry.proofKind = ProofKind.placeholderTruth ||
      entry.proofKind = ProofKind.heuristicOther)

def exactnessLockPendingEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.exactnessLockPending)

def publicProbabilisticBridgeEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.publicProbabilisticBridgeSurface)

def publicProbabilisticBridgeWitnessHypEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.publicProbabilisticBridgeWitnessHyp)

def publicProbabilisticBridgeEquationHypEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.publicProbabilisticBridgeEquationHyp)

def publicProbabilisticBridgeConcreteRootEntryCount : Nat :=
  manifestEntries.countP (fun entry => entry.publicProbabilisticBridgeConcreteRoot)

def concreteSubstrateModuleCount : Nat := 11

def bridgeReadyAbstractEntryCount : Nat :=
  manifestEntries.countP (fun entry =>
    entry.firstPrinciplesStatus = FirstPrinciplesStatus.abstractInterface &&
      match entry.leanModule with
      | "SemanticConvergence.Belief" => true
      | "SemanticConvergence.Boundary" => true
      | "SemanticConvergence.Foundations" => true
      | "SemanticConvergence.Functional" => true
      | "SemanticConvergence.Hierarchy" => true
      | "SemanticConvergence.Noise" => true
      | "SemanticConvergence.Rates" => true
      | "SemanticConvergence.SelfReference" => true
      | "SemanticConvergence.Semantic" => true
      | "SemanticConvergence.Surrogate" => true
      | _ => false)

def unlabeledEntryCount : Nat :=
  manifestEntries.foldl
    (fun acc entry => if entry.texLabel.startsWith "auto__" then acc + 1 else acc)
    0

theorem derivedEntryCount_eq : derivedEntryCount = 106 := by
  native_decide

theorem wrappedEntryCount_eq : wrappedEntryCount = 0 := by
  native_decide

theorem declaredEntryCount_eq : declaredEntryCount = 0 := by
  native_decide

theorem concreteStackEntryCount_eq : concreteStackEntryCount = 106 := by
  native_decide

theorem abstractInterfaceEntryCount_eq : abstractInterfaceEntryCount = 0 := by
  native_decide

theorem migratedToConcreteEntryCount_eq : migratedToConcreteEntryCount = 106 := by
  native_decide

theorem pendingConcreteMigrationEntryCount_eq : pendingConcreteMigrationEntryCount = 0 := by
  native_decide

theorem substantiveEntryCount_eq : substantiveEntryCount = 60 := by
  native_decide

theorem definitionProofEntryCount_eq : definitionProofEntryCount = 35 := by
  native_decide

theorem constructiveExistentialEntryCount_eq : constructiveExistentialEntryCount = 8 := by
  native_decide

theorem rateCompositionEntryCount_eq : rateCompositionEntryCount = 3 := by
  native_decide

theorem singleLemmaApplicationEntryCount_eq : singleLemmaApplicationEntryCount = 0 := by
  native_decide

theorem definitionalUnfoldEntryCount_eq : definitionalUnfoldEntryCount = 0 := by
  native_decide

theorem fieldProjectionEntryCount_eq : fieldProjectionEntryCount = 0 := by
  native_decide

theorem placeholderTruthEntryCount_eq : placeholderTruthEntryCount = 0 := by
  native_decide

theorem heuristicOtherEntryCount_eq : heuristicOtherEntryCount = 0 := by
  native_decide

theorem manifestDefinitionEntryCount_eq : manifestDefinitionEntryCount = 28 := by
  native_decide

theorem manifestDefinitionEntriesTaggedAsDefinitionCount_eq : manifestDefinitionEntriesTaggedAsDefinitionCount = 28 := by
  native_decide

theorem manifestTheoremLikeEntryCount_eq : manifestTheoremLikeEntryCount = 78 := by
  native_decide

theorem manifestTheoremLikeSemanticallyAuditedEntryCount_eq : manifestTheoremLikeSemanticallyAuditedEntryCount = 78 := by
  native_decide

theorem suspiciousManifestEntryCount_eq : suspiciousManifestEntryCount = 0 := by
  native_decide

theorem exactnessLockPendingEntryCount_eq : exactnessLockPendingEntryCount = 4 := by
  native_decide

theorem publicProbabilisticBridgeEntryCount_eq : publicProbabilisticBridgeEntryCount = 8 := by
  native_decide

theorem publicProbabilisticBridgeWitnessHypEntryCount_eq : publicProbabilisticBridgeWitnessHypEntryCount = 0 := by
  native_decide

theorem publicProbabilisticBridgeEquationHypEntryCount_eq : publicProbabilisticBridgeEquationHypEntryCount = 0 := by
  native_decide

theorem publicProbabilisticBridgeConcreteRootEntryCount_eq : publicProbabilisticBridgeConcreteRootEntryCount = 8 := by
  native_decide

theorem concreteSubstrateModuleCount_eq : concreteSubstrateModuleCount = 11 := rfl

theorem bridgeReadyAbstractEntryCount_eq : bridgeReadyAbstractEntryCount = 0 := by
  native_decide

def moduleAbstractInterfaceEntryCount (moduleName : String) : Nat :=
  manifestEntries.countP (fun entry =>
    entry.leanModule = moduleName &&
      entry.firstPrinciplesStatus = FirstPrinciplesStatus.abstractInterface)

def modulePendingConcreteMigrationEntryCount (moduleName : String) : Nat :=
  manifestEntries.countP (fun entry =>
    entry.leanModule = moduleName &&
      entry.migrationStatus = MigrationStatus.pendingConcreteMigration)

def moduleFirstPrinciplesClosed (moduleName : String) : Bool :=
  modulePendingConcreteMigrationEntryCount moduleName = 0

theorem unlabeledEntryCount_eq : unlabeledEntryCount = 0 := by
  native_decide

def paperFullyCovered : Bool :=
  declaredEntryCount = 0 && unlabeledEntryCount = 0

def paperFullyDerived : Bool :=
  wrappedEntryCount = 0 && paperFullyCovered

def semanticAuditClosed : Bool :=
  suspiciousManifestEntryCount = 0 &&
    manifestDefinitionEntriesTaggedAsDefinitionCount = manifestDefinitionEntryCount &&
    manifestTheoremLikeSemanticallyAuditedEntryCount = manifestTheoremLikeEntryCount

def semanticExactnessClosed : Bool :=
  exactnessLockPendingEntryCount = 0

def publicProbabilisticBridgeSurfaceClosed : Bool :=
  publicProbabilisticBridgeEntryCount = 8 &&
    publicProbabilisticBridgeWitnessHypEntryCount = 0 &&
    publicProbabilisticBridgeEquationHypEntryCount = 0 &&
    publicProbabilisticBridgeConcreteRootEntryCount = publicProbabilisticBridgeEntryCount

def fullyCovered : Bool :=
  paperFullyCovered

def fullyDerived : Bool :=
  paperFullyDerived

def fullyFirstPrinciples : Bool :=
  abstractInterfaceEntryCount = 0 && paperFullyDerived && semanticAuditClosed &&
    semanticExactnessClosed && publicProbabilisticBridgeSurfaceClosed

theorem paperFullyCovered_eq : paperFullyCovered = true := by
  native_decide

theorem paperFullyDerived_eq : paperFullyDerived = true := by
  native_decide

theorem semanticAuditClosed_eq : semanticAuditClosed = true := by
  native_decide

theorem semanticExactnessClosed_eq : semanticExactnessClosed = false := by
  native_decide

theorem publicProbabilisticBridgeSurfaceClosed_eq : publicProbabilisticBridgeSurfaceClosed = true := by
  native_decide

theorem fullyCovered_eq : fullyCovered = paperFullyCovered := rfl

theorem fullyDerived_eq : fullyDerived = paperFullyDerived := rfl

theorem fullyFirstPrinciples_eq : fullyFirstPrinciples = false := by
  native_decide

end SemanticConvergence
