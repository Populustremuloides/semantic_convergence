# Lean verification — open issues (current as of Apr 25, 2026)

This is the single canonical issues document for the Lean formalization of the
algorithmic free energy paper. It supersedes and replaces all prior audit
documents (`lean_verification_remaining_issues.md`, `lean_adversarial_review.md`,
`lean_sixth_pass_findings.md`, `lean_seventh_pass_findings.md`,
`lean_blind_audit.md`, `paper_claim_drift_audit.md`). The preface gives a brief
history of those passes — what they got right, what they got wrong, and what
was overstated — so that the current open-issues list can be read with full
context. The body lists current open issues. The closing section summarizes the
manifest's own self-reported audit booleans.

---

## Preface — history of prior audits

Eight adversarial audit passes have been run, plus one paper-side drift audit.
This section records what each pass got right and where each pass was wrong or
overstated, so a future reader is not misled by stale findings.

### Original review (`lean_adversarial_review.md`) and first hand-off (A-series, A1–A10)

Established the original ten deliverables. All A-items have since been closed
or supplanted by later passes. The A-series itself is no longer load-bearing.

### Second hand-off (B-series, B1–B5)

Mechanical items. B1, B2, B4, B5 closed in their respective passes. B3 (olean
freshness) is recurring and depends on whether `lake build` was run; it is
treated as administrative.

### Fifth pass (D-series, D1–D6)

The fifth pass identified the central structural complaint that has shaped all
subsequent audits: that the probabilistic master theorem launders a hypothesis.
That complaint, named D1 here, was correct. Variants of it have appeared in
every subsequent pass under different names. **D1's substantive content has
not been fully closed; it has been refactored into transparency** — see G1
below.

D2–D3 (substrate mismatch) were correctly identified as a real issue and have
since been addressed by `ConcreteSubstrateBridge.lean` (1845 lines) and
explicit substrate-conversion machinery. D4 (olean staleness) is administrative.
D5–D6 (manifest substrate ambiguity, paper wording) were closed.

### Sixth pass (E-series, E1–E6)

E1 correctly noticed the manifest had retagged two entries
(`lem_one_step_drift`, `prop_exp_rate`) as `singleLemmaApplication`, exposing
that the prior `suspiciousManifestEntryCount = 0` claim was inaccurate. This
forced a correction. The current count is back to 0 with all retags applied.

E3, E4, E5 correctly identified three theorems tagged `substantive` whose
proof bodies were trivial (`rfl` or hypothesis-identity reconstruction). All
three have since been retagged: `cor_efe_specialization` and `lem_risk_ig` to
`ProofKind.definition`, `thm_afe_near_miss` to `ProofKind.constructiveExistential`.

E2 was a restatement of D1 at higher resolution. E6 correctly identified that
`thm_amortized_surrogate` lacked the paper's standing assumptions (A1)–(A3).
Both have since been closed at the named-theorem level.

### Seventh pass (F-series, F1–F6)

The seventh pass made one specific factual error worth flagging:

> **Seventh-pass F2 said `def_afe` was a binary indicator
> `if samePosteriorWeights then 0 else 1` in `Belief.lean` L28–33.**
>
> This was wrong on both location and form. `def_afe` lives in `Functional.lean`,
> not `Belief.lean`. At the time of the seventh pass it was a sum of generalized
> KL terms against the unnormalized posterior weights, not a binary indicator.
> The seventh-pass agent appears to have read an earlier or unrelated definition
> and treated it as the current one.

The seventh pass's F1 (two-observer functional was a scalar product, not a
three-term Gibbs variational) was correct at the time and has since been closed:
`def_two_observer_functional` is now `def_afe - β·observerClassExpectedScore +
γ·observerClassPriorKLDivergence`, which is the paper's three-term form.

F3, F4, F5, F6 were variously correct and have been addressed at the named-item
level. F5 specifically is closed — `prop_two_observer_minimizer` exists in
`Functional.lean` L565 (and a refined version in `Belief.lean` L604).

### Blind pass (Blind-1 through Blind-6)

The blind pass was performed without access to prior audit files. It
independently rediscovered most of the structural concerns from D, E, and F
series. Specifically:

- Blind-1 was a sharper restatement of F2: `def_afe` was a divergence in the
  wrong direction (against the unnormalized posterior, not the prior). This was
  a more accurate characterization than F2's "binary indicator" claim. Blind-1
  was correct at the time it was written. It has since been closed by a real
  rewrite of `def_afe` to `expectedHistoryFitLoss U π t h q + priorKLDivergence U q`
  (Functional.lean L367–371, returns `Real`, structurally matches the paper's
  $\mathbb E_q[L_t]+\mathrm{KL}(q\|w)$).

- Blind-3 / Blind-5 (main theorem takes its conclusion as a hypothesis) is the
  same structural complaint as D1, and the same complaint persists today as G1.
  The hypothesis name has changed three times: `HasSupportwiseResidualContractionWitness`
  (D1) → `hBridge` (E2) → `hStep` (current). The bridge constructor between
  deterministic `hStep` and the probabilistic supportwise witness is now real
  derivation work. What's still missing is any theorem that derives `hStep`
  itself from the paper's foundational assumptions.

The blind pass made one error worth noting: it claimed `prop_two_observer_minimizer`
did not exist on the countable stack at the time. This was wrong; it existed in
`Functional.lean` L565. The blind agent appears not to have searched the
correct file.

### Paper drift audit

Verified that the paper itself has not been weakened to accommodate Lean
limitations. The paper's Definition 6 (algorithmic free energy) still reads as
$\mathcal F_t[q;h_t]:=\mathbb E_q[L_t]+\mathrm{KL}(q\|w)$. Definition 9
(two-observer functional) still has the three-term Gibbs form. The remediation
agent's edits to the abstract and conclusion are toward more specific Lean
correspondence language, not hedging. **One caveat:** the abstract phrase "with
no external bridge-equation hypothesis left on the public theorem surface"
(commit 930833d) is true literally — `hBridge` is gone — but slightly overpromises
in spirit, because `hStep` plays the same structural role at one level of
indirection. Consider softening that phrase or annotating it to say "no
hypothesis on the supportwise countable witness" rather than "no
bridge-equation hypothesis."

### Summary of where the field has settled

Significant remediation has occurred. As of this audit, the manifest's own
self-reported booleans show:

| Boolean | Value |
| --- | --- |
| `abstractInterfaceEntryCount` | 0 |
| `suspiciousManifestEntryCount` | 0 |
| `paperFullyDerived` | true |
| `semanticAuditClosed` | true |
| `publicProbabilisticBridgeSurfaceClosed` | true |
| `exactnessLockPendingEntryCount` | **4** |
| `semanticExactnessClosed` | **false** |
| `fullyFirstPrinciples` | **false** |

The tree honestly reports — through the manifest itself, by `native_decide` — that
it is not yet fully first-principles. Four entries are pending exactness lock,
and `semanticExactnessClosed = false`. This self-reporting is consistent with
the structural complaint that has run through every adversarial pass: the main
theorem still takes a per-step contraction hypothesis as input rather than
deriving it.

---

## Open issues (current)

### Critical

#### G1. The main theorem `thm_separating_support_convergence` still takes a per-step contraction hypothesis as input

*Severity.* Critical. This is the structural concern that has run through D1, E2,
Blind-3, Blind-5, and is the present-day form of the persistent laundering issue.

*Source location.* `Semantic.lean` L492–535. The hypothesis `hStep` is at L505–513:

```
(hStep :
  ∀ ξ, ξ ∈ ((U.toCountablePrefixMachine hSem).trajectoryLaw
    (toCountablePolicy π hπ) (U.toCountableProgram hSem penv) T).support →
    ∀ n, n < T →
      U.residualObserverFiberPosteriorOdds π (prefixFullHist ξ (n + 1)) ω
          (U.toEncodedProgram pstar) ≤
        posteriorDecayFactor δ *
          U.residualObserverFiberPosteriorOdds π (prefixFullHist ξ n) ω
            (U.toEncodedProgram pstar))
```

*Problem.* `hStep` asserts "for every trajectory in the support, at every step,
the residual observer-fiber posterior odds decay by `posteriorDecayFactor δ`."
The conclusion of the theorem (after the bridge) is the almost-sure version of
the same statement. The bridge constructor
`hasSupportwiseResidualContractionWitness_of_prefixwiseResidualDecay`
(`ConcreteSubstrateBridge.lean` L1794) does real work to convert the deterministic
prefixwise statement into the supportwise countable witness — that is genuine
derivation. But `hStep` itself, the per-step contraction, is not derived
anywhere in the tree from the paper's advertised foundational assumptions
(Bayes/Gibbs posterior + separating-support condition + bounded log-likelihood
ratios).

*What the paper claims.* The paper's Theorem on separating-support convergence
states that under foundational assumptions (universal prior, Bayes/Gibbs belief,
semantic separation, divergent cumulative policy mass on separating actions),
the posterior on the interventional class converges almost surely with
explicit finite-time rates. The Lean theorem proves a strictly weaker
implication: assuming the per-step contraction holds, the corresponding a.s.
N-step bound holds.

*Acceptance criteria.* Either:
1. Add a theorem `hStep_from_separating_support` (or equivalent) deriving
   `hStep` from the paper's foundational hypotheses. This would close G1
   substantively.
2. Document in `Semantic.lean` (and in the paper, especially the abstract
   sentence "with no external bridge-equation hypothesis left on the public
   theorem surface") that `hStep` is a standing assumption, the form of the
   contraction is inherited from the deterministic Section 6 stack, and the
   theorem's contribution is the bridge plus the N-step upgrade rather than a
   first-principles derivation.

The manifest's `exactnessLockPendingEntryCount = 4` and
`semanticExactnessClosed = false` are believed to track this gap; verifying
exactly which four entries are pending would help target the remediation.

### Substantive

#### G2. `DiscreteConvexDuality.lean` is not tightly integrated with the paper-facing surface

*Severity.* Substantive.

*Source location.* `DiscreteConvexDuality.lean` (4009 lines, the largest single
file in the tree); `Belief.lean` L549–570 (`lem_kl_necessity`).

*Problem.* `DiscreteConvexDuality.lean` proves the generic Gibbs variational
identity (`exactBoundedLossFormula_eq_kl` at L3868) and the supporting
machinery (Fenchel-Moreau-style duality for divergences on the countable
simplex). This is the mathematical content the paper's Lemma 2 (`lem_kl_necessity`,
"KL is forced by the exact Gibbs variational formula") rests on. The Lean
`lem_kl_necessity` does invoke `exactBoundedLossFormula_eq_kl`, so the module
is not entirely orphaned. But the connection from the generic
`ExactBoundedLossFormula D w` predicate to the specific countable-machine
divergence functional `def_afe` is not stated as an explicit instantiation.

A reader trying to verify "the paper's Lemma 2 is formalized in Lean" must
manually trace the connection across multiple files rather than seeing one
explicit bridging lemma.

*Acceptance criterion.* Add an explicit instantiation lemma:
`countableDivergence_satisfies_exactBoundedLossFormula : ExactBoundedLossFormula
(genericWeightKLDivergenceEReal · w) w` (or similar), and have `lem_kl_necessity`
reference it directly.

#### G3. Paper abstract phrase "no external bridge-equation hypothesis" is technically true but understates the residual issue

*Severity.* Substantive (paper-side).

*Source location.* `semantic_convergence_interactive_learning.tex`, abstract
Lean paragraph (around line 54), introduced in commit 930833d.

*Problem.* The phrase "with no external bridge-equation hypothesis left on the
public theorem surface" is literally accurate — `hBridge` no longer appears
anywhere. But the same structural concern persists in the form of `hStep`,
which is on the public theorem surface and is the deterministic per-step
contraction. A careful reader of the abstract may infer the Lean theorem
derives convergence from foundational assumptions, when in fact it derives the
N-step a.s. bound from a per-step deterministic input.

*Acceptance criterion.* Soften the phrase to either:
- "with no supportwise-witness hypothesis left on the public theorem surface"
  (which is what the bridge constructor actually closed), or
- explicit acknowledgment: "the public theorem accepts the deterministic
  per-step contraction as a hypothesis and bridges it to an almost-sure
  countable conclusion; deriving the per-step contraction from foundational
  assumptions remains a standing item."

This pairs with G1; if G1 is closed substantively, G3 self-resolves.

### Minor

#### G4. `prop_two_observer_minimizer` proves a zero-crossing characterization rather than a global-minimization statement

*Severity.* Minor (the substantive minimization may follow from auxiliary
lemmas, but the theorem statement itself is zero-iff-equality).

*Source location.* `Functional.lean` L565 (older version) and `Belief.lean` L604
(refined version).

*Problem.* The theorem proves
`def_two_observer_functional ... = 0 ↔ samePosteriorWeights q ∧ agreesWithOnTargets ν gibbs`.
This is a zero-crossing characterization. The paper's Proposition 8 claims
something stronger: that the Bayes/Gibbs posterior uniquely minimizes (not
merely zeroes) the three-term variational functional. Given that
`def_two_observer_functional` is now structurally a sum of nonnegative divergence
terms, zero-iff-equality and minimum-iff-equality coincide, but the theorem
statement does not say the latter directly.

*Acceptance criterion.* Either restate the theorem as
`def_two_observer_functional ... ≥ 0 ∧ minimum equals 0 iff …`, or add a
companion corollary that exposes the global-minimum framing.

#### G5. `lem_kl_necessity` has an indirect proof structure

*Severity.* Minor.

*Source location.* `Belief.lean` L549–570.

*Problem.* The proof computes a lower bound (`exactBoundedLossFormula_ge_kl`)
and an equality (`exactBoundedLossFormula_eq_kl`) and then combines them via
`le_of_eq`. The equality alone suffices; the lower-bound step is redundant.

*Acceptance criterion.* Simplify to use `exactBoundedLossFormula_eq_kl`
directly, or document why the dual-step formulation is preferred.

#### G6. Surrogate theorems prove "supporting mass" but not "exclusive support"

*Severity.* Minor (depends on paper interpretation).

*Source location.* `Surrogate.lean` L257–293 (concrete) and L129–188 (countable).

*Problem.* Both theorems conclude `hasSeparatingSupportOn highScoreActions
(separatingActionSet ...)` — the surrogate law puts mass on high-score actions —
but do not negate support on other actions. If the paper's Theorem 11.1
requires exclusive support on high-score actions, this is a gap; if it merely
requires positive mass on the high-score set, the gap is illusory.

*Acceptance criterion.* Confirm against the paper which is intended. Either
add a `¬ hasSeparatingSupportOn otherActions` companion conclusion, or
document that the paper does not require exclusivity.

### Administrative

#### G7. Olean freshness cannot be verified in this sandbox

*Severity.* Administrative.

*Source location.* `Manifest.olean`, `AxiomAudit.olean` and dependents.

*Problem.* The Lean toolchain is not installed in this audit sandbox, so
`lake build` cannot be run. Stale oleans would mean that the manifest's
closing-theorem `native_decide` results may not reflect the current source.

*Acceptance criterion.* Run `lake clean && lake build` on the developer
machine. Verify that all `.olean` files have `mtime ≥` the corresponding
`.lean` source. Re-render `lean_axiom_audit.md` from the fresh
`AxiomAudit.olean`.

---

## Manifest closing-theorem snapshot

For the record, the following closure values are in `Manifest.lean` and
asserted by `native_decide`:

| Theorem | Reported value | Source |
| --- | --- | --- |
| `abstractInterfaceEntryCount_eq` | `= 0` | L2107 |
| `suspiciousManifestEntryCount_eq` | `= 0` | L2155 |
| `exactnessLockPendingEntryCount_eq` | `= 4` | L2158 |
| `paperFullyDerived_eq` | `= true` | L2227 |
| `semanticAuditClosed_eq` | `= true` | L2230 |
| `semanticExactnessClosed_eq` | `= false` | L2233 |
| `publicProbabilisticBridgeSurfaceClosed_eq` | `= true` | L2236 |
| `fullyFirstPrinciples_eq` | `= false` | L2243 |

The two `false` values (`semanticExactnessClosed`, `fullyFirstPrinciples`) are
the manifest's own honest acknowledgement that the formalization is not yet
closed at the strongest level. They are believed to track the same gap as G1.

These values are subject to G7: if the harness `.olean` files are stale, the
`native_decide` results may not reflect the current source. The values are
recorded here as of the eighth-pass read; verify with `lake build` before
relying on them.

---

## Recommended close-out work order

1. **G1** — Either derive `hStep` from foundational assumptions, or add
   visible documentation (in `Semantic.lean`, the manifest, the paper abstract,
   and the paper's main-theorem statement) that `hStep` is a standing
   assumption inherited from the deterministic Section 6 stack. This is the
   single highest-leverage item.

2. **G3** — Soften the abstract phrase about "no bridge-equation hypothesis"
   to align with whatever G1's resolution looks like.

3. **G7** — Run `lake clean && lake build`. Verify olean freshness. Re-render
   `lean_axiom_audit.md`.

4. **G2** — Add an explicit instantiation lemma connecting
   `DiscreteConvexDuality.lean`'s generic theorems to the paper-facing
   `def_afe`.

5. **G4, G5, G6** — Cosmetic / stylistic polish. Either fold into the next
   editing round or defer.

If the goal is to reach `fullyFirstPrinciples = true`, G1 is the load-bearing
item; G7 is the verification step. If the goal is "fit to publish as a
technical artifact with clearly documented assumptions," G1 documentation
(option 2 above) plus G3 is sufficient.
